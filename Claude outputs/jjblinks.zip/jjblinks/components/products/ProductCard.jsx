import Link from 'next/link';
import { Photo } from '@/components/ui/Photo';
import Price from './Price';

export function ProductCard({ product, ctx, priority = false }) {
  const p = product;
  return (
    <article className="group relative">
      <Link href={`/products/${p.slug}`} className="block">
        <div className="relative aspect-[4/5] overflow-hidden bg-ivory-deep">
          <Photo src={p.image_url} alt={p.image_alt || p.name} sizes="(min-width: 1024px) 22vw, (min-width: 640px) 45vw, 90vw" priority={priority}
            className="transition-transform duration-700 group-hover:scale-[1.03]" />
          {!p.in_stock && <span className="absolute left-0 top-3 bg-charcoal px-2.5 py-1 text-xs text-ivory">Sold out</span>}
          {p.is_sample && <span className="absolute right-0 top-3 bg-gold px-2.5 py-1 text-xs text-charcoal">Sample</span>}
        </div>
        <div className="mt-3 flex flex-col gap-1">
          {p.category_name && <p className="text-xs text-muted">{p.category_name}</p>}
          <h3 className="font-display text-xl leading-snug group-hover:text-wine">{p.name}</h3>
          <p className="text-sm">
            <Price kobo={p.from_price_kobo} compareKobo={p.has_price_range ? null : p.compare_at_kobo} ctx={ctx} from={p.has_price_range} />
          </p>
        </div>
      </Link>
    </article>
  );
}

export function ProductGrid({ products, ctx, priorityCount = 0 }) {
  return (
    <div className="grid grid-cols-2 gap-x-4 gap-y-10 sm:gap-x-6 lg:grid-cols-4">
      {products.map((p, i) => <ProductCard key={p.id} product={p} ctx={ctx} priority={i < priorityCount} />)}
    </div>
  );
}

export function Pagination({ page, pages, makeHref }) {
  if (pages <= 1) return null;
  const nums = [];
  for (let i = Math.max(1, page - 2); i <= Math.min(pages, page + 2); i++) nums.push(i);
  return (
    <nav aria-label="Pagination" className="mt-14 flex items-center justify-center gap-2 text-sm">
      {page > 1 && <Link className="px-3 py-2 hover:text-wine" href={makeHref(page - 1)}>Previous</Link>}
      {nums.map((n) =>
        n === page ? (
          <span key={n} aria-current="page" className="border-b border-burgundy px-3 py-2 text-burgundy">{n}</span>
        ) : (
          <Link key={n} href={makeHref(n)} className="px-3 py-2 hover:text-wine">{n}</Link>
        )
      )}
      {page < pages && <Link className="px-3 py-2 hover:text-wine" href={makeHref(page + 1)}>Next</Link>}
    </nav>
  );
}
