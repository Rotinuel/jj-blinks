import Image from 'next/image';

/** Labelled stand-in shown wherever a real photograph has not been uploaded yet. */
export function Placeholder({ label = 'Photograph coming soon', dark = false, className = '' }) {
  return (
    <div role="img" aria-label={label} className={`${dark ? 'placeholder placeholder-dark' : 'placeholder'} ${className}`}>
      <span className="px-3 text-center text-xs tracking-wide">{label}</span>
    </div>
  );
}

/** Fills its (positioned, sized) parent. Falls back to a labelled placeholder. */
export function Photo({ src, alt = '', sizes = '100vw', priority = false, className = '', placeholderLabel, dark }) {
  if (!src) return <Placeholder label={placeholderLabel} dark={dark} />;
  return <Image src={src} alt={alt} fill sizes={sizes} priority={priority} className={`object-cover ${className}`} />;
}
