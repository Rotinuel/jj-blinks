'use client';

import Link from 'next/link';
import { useEffect, useRef, useState } from 'react';
import { usePathname } from 'next/navigation';
import { useCart } from '@/components/cart/CartProvider';
import { setCurrencyAction } from '@/app/actions/store';

export function BagLink() {
  const { count, ready } = useCart();
  return (
    <Link href="/cart" className="relative inline-flex items-center gap-1.5 py-2 text-sm hover:text-wine">
      <BagIcon />
      <span>Bag</span>
      {ready && count > 0 && (
        <span className="ml-0.5 min-w-5 bg-burgundy px-1.5 text-center text-xs leading-5 text-ivory" aria-label={`${count} items`}>
          {count}
        </span>
      )}
    </Link>
  );
}

export function CurrencySelect({ currency, currencies, enabled }) {
  if (!enabled) return null;
  return (
    <form action={setCurrencyAction} className="flex items-center">
      <label htmlFor="currency" className="sr-only">Display currency</label>
      <select
        id="currency"
        name="currency"
        defaultValue={currency}
        onChange={(e) => e.currentTarget.form.requestSubmit()}
        className="cursor-pointer bg-transparent py-1 pr-1 text-sm"
      >
        {currencies.map((c) => <option key={c} value={c}>{c}</option>)}
      </select>
      <noscript><button className="text-sm underline">Set</button></noscript>
    </form>
  );
}

export function MobileMenu({ links, collections }) {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();
  const dialog = useRef(null);
  useEffect(() => setOpen(false), [pathname]);
  useEffect(() => {
    const d = dialog.current;
    if (!d) return;
    if (open && !d.open) d.showModal();
    if (!open && d.open) d.close();
  }, [open]);

  return (
    <>
      <button type="button" className="py-2 text-sm lg:hidden" aria-expanded={open} aria-controls="mobile-menu" onClick={() => setOpen(true)}>
        Menu
      </button>
      <dialog
        id="mobile-menu"
        ref={dialog}
        onClose={() => setOpen(false)}
        className="m-0 h-dvh max-h-none w-[min(24rem,90vw)] max-w-none bg-ivory p-0 text-charcoal backdrop:bg-charcoal/50"
      >
        <div className="flex items-center justify-between border-b border-line px-6 py-4">
          <span className="font-display text-xl tracking-[0.2em]">JJ BLINKS</span>
          <button type="button" className="text-sm" onClick={() => setOpen(false)}>Close</button>
        </div>
        <nav className="px-6 py-6" aria-label="Mobile">
          <ul className="space-y-4 font-display text-2xl">
            {links.map((l) => <li key={l.href}><Link href={l.href}>{l.label}</Link></li>)}
          </ul>
          <p className="mt-8 text-sm text-muted">Collections</p>
          <ul className="mt-3 space-y-2">
            {collections.map((c) => <li key={c.slug}><Link href={`/collections/${c.slug}`}>{c.name}</Link></li>)}
          </ul>
          <ul className="mt-8 space-y-2 text-sm">
            <li><Link href="/account">Your account</Link></li>
            <li><Link href="/track">Track an order</Link></li>
            <li><Link href="/contact">Contact</Link></li>
          </ul>
        </nav>
      </dialog>
    </>
  );
}

function BagIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" aria-hidden="true">
      <path d="M5 8h14l-1 13H6L5 8Z" />
      <path d="M9 8V6a3 3 0 0 1 6 0v2" />
    </svg>
  );
}
