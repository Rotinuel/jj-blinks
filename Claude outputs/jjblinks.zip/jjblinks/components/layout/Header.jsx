import Link from 'next/link';
import { getNavCategories, getStoreContext } from '@/lib/storefront';
import { DISPLAY_CURRENCIES } from '@/lib/currency';
import { getCurrentUser } from '@/lib/auth';
import { BagLink, CurrencySelect, MobileMenu } from './HeaderClient';

const LINKS = [
  { href: '/shop', label: 'Shop' },
  { href: '/new-arrivals', label: 'New in' },
  { href: '/custom-orders', label: 'Custom orders' },
  { href: '/bulk-orders', label: 'Bulk & corporate' },
  { href: '/about', label: 'About' },
];

export default async function Header() {
  const [{ settings, currency, fxEnabled }, collections, user] = await Promise.all([
    getStoreContext(),
    getNavCategories(),
    getCurrentUser(),
  ]);
  const a = settings.announcement;
  return (
    <>
      {a.enabled && a.text && (
        <div className="bg-burgundy text-ivory">
          <p className="wrap py-2 text-center text-[0.82rem]">
            {a.link ? <Link href={a.link} className="hover:underline">{a.text}</Link> : a.text}
          </p>
        </div>
      )}
      <header className="sticky top-0 z-30 border-b border-line bg-ivory/95 backdrop-blur-sm">
        <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-2 focus:bg-ivory focus:px-3 focus:py-2">
          Skip to content
        </a>
        <div className="wrap grid grid-cols-[1fr_auto_1fr] items-center gap-4 py-3">
          <div className="flex items-center gap-6">
            <MobileMenu links={LINKS} collections={collections} />
            <nav aria-label="Main" className="hidden lg:block">
              <ul className="flex gap-6 text-sm">
                {LINKS.map((l) => (
                  <li key={l.href}><Link href={l.href} className="py-2 hover:text-wine">{l.label}</Link></li>
                ))}
              </ul>
            </nav>
          </div>
          <Link href="/" className="font-display text-[1.65rem] leading-none tracking-[0.24em] text-burgundy sm:text-3xl" aria-label="JJ BLINKS home">
            JJ BLINKS
          </Link>
          <div className="flex items-center justify-end gap-4 sm:gap-5">
            <Link href="/search" className="hidden py-2 text-sm hover:text-wine sm:inline">Search</Link>
            <Link href={user ? '/account' : '/login'} className="hidden py-2 text-sm hover:text-wine sm:inline">
              {user ? 'Account' : 'Sign in'}
            </Link>
            <CurrencySelect currency={currency} currencies={DISPLAY_CURRENCIES} enabled={fxEnabled} />
            <BagLink />
          </div>
        </div>
      </header>
    </>
  );
}
