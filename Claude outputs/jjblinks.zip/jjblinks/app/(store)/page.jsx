import Link from 'next/link';
import { getNavCategories, getStoreContext } from '@/lib/storefront';
import { bestSellers, featuredProducts, newArrivals } from '@/db/queries/catalog';
import { Photo } from '@/components/ui/Photo';
import { ProductGrid } from '@/components/products/ProductCard';
import { whatsappLink } from '@/lib/utilities';

export const metadata = { alternates: { canonical: '/' } };

const STEPS = [
  ['Share your brief', 'Tell us the occasion, colours and quantity, and add reference photos.'],
  ['Receive a quotation', 'We confirm what can be made, the price and the timeline.'],
  ['Approve and pay', 'You pay only after you accept the quotation.'],
  ['Made and delivered', 'Follow progress from production to delivery.'],
];

export default async function HomePage() {
  const ctx = await getStoreContext();
  const [collections, arrivals, best, featured] = await Promise.all([
    getNavCategories(), newArrivals(8), bestSellers(4), featuredProducts(4),
  ]);
  const h = ctx.settings.home;
  const wa = whatsappLink(ctx.settings.store.whatsapp, 'Hello JJ BLINKS, I would like to discuss a custom order.');
  const curated = best.length ? { title: 'Best sellers', items: best } : featured.length ? { title: 'Selected pieces', items: featured } : null;

  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden bg-burgundy text-ivory">
        <div className="wrap grid items-end gap-10 pb-14 pt-14 md:grid-cols-12 md:pb-0 md:pt-20">
          <div className="md:col-span-7 md:pb-24">
            {h.hero.eyebrow && <p className="mb-6 text-sm text-gold">{h.hero.eyebrow}</p>}
            <h1 className="font-display text-display">
              {splitHeadline(h.hero.headline).map((line, i) => (
                <span key={i} className="hero-line block">{line}</span>
              ))}
            </h1>
            <p className="mt-8 max-w-md text-ivory/80">{h.hero.subheading}</p>
            <div className="mt-10 flex flex-wrap items-center gap-6">
              <Link href="/shop" className="btn btn-light">Shop the collection</Link>
              <Link href="/custom-orders" className="border-b border-gold pb-1 text-sm hover:text-gold">Start a custom order</Link>
            </div>
          </div>
          <div className="relative md:col-span-5 md:-mb-px md:self-end">
            <div className="hero-figure arch relative mx-auto aspect-[3/4] w-full max-w-md border border-gold/40 md:translate-y-10">
              <Photo src={h.hero.image_url} alt={h.hero.image_alt} sizes="(min-width: 768px) 40vw, 90vw" priority dark placeholderLabel="Campaign photograph coming soon" />
            </div>
          </div>
        </div>
      </section>

      {/* Collections rail */}
      <section className="wrap pt-24" aria-labelledby="collections-title">
        <div className="mb-8 flex items-end justify-between gap-6">
          <h2 id="collections-title" className="font-display text-title">Shop by crown</h2>
          <Link href="/shop" className="link shrink-0 text-sm">All pieces</Link>
        </div>
        <ul className="rail">
          {collections.map((c) => (
            <li key={c.slug}>
              <Link href={`/collections/${c.slug}`} className="group block">
                <div className="arch relative aspect-[3/4] bg-ivory-deep">
                  <Photo src={c.image_url} alt={c.image_alt || c.name} sizes="18rem" placeholderLabel={c.name} />
                </div>
                <p className="mt-3 font-display text-xl group-hover:text-wine">{c.name}</p>
                <p className="text-xs text-muted">{c.product_count ? `${c.product_count} ${c.product_count === 1 ? 'piece' : 'pieces'}` : 'Enquire for availability'}</p>
              </Link>
            </li>
          ))}
        </ul>
      </section>

      {/* New arrivals */}
      {arrivals.length > 0 && (
        <section className="wrap pt-24" aria-labelledby="new-title">
          <div className="mb-10 flex items-end justify-between gap-6">
            <h2 id="new-title" className="font-display text-title">New in</h2>
            <Link href="/new-arrivals" className="link shrink-0 text-sm">See all new pieces</Link>
          </div>
          <ProductGrid products={arrivals} ctx={ctx} />
        </section>
      )}

      {/* Custom orders */}
      <section className="mt-28 bg-rose-tint" aria-labelledby="custom-title">
        <div className="wrap grid gap-12 py-20 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <div className="relative aspect-[4/5] w-full">
              <Photo src={h.custom_feature.image_url} alt={h.custom_feature.image_alt} sizes="(min-width: 1024px) 38vw, 90vw" placeholderLabel="Custom work photograph coming soon" />
            </div>
          </div>
          <div className="lg:col-span-6 lg:col-start-7 lg:self-center">
            <h2 id="custom-title" className="font-display text-title">{h.custom_feature.heading}</h2>
            <p className="measure mt-5 text-lg">{h.custom_feature.text}</p>
            <ol className="mt-10 grid gap-6 sm:grid-cols-2">
              {STEPS.map(([title, text], i) => (
                <li key={title} className="border-t border-burgundy/30 pt-4">
                  <p className="font-display text-3xl text-burgundy">{i + 1}</p>
                  <p className="mt-1 font-medium">{title}</p>
                  <p className="mt-1 text-sm text-muted">{text}</p>
                </li>
              ))}
            </ol>
            <div className="mt-10 flex flex-wrap items-center gap-6">
              <Link href="/custom-orders" className="btn btn-primary">Request a custom piece</Link>
              {wa && <a href={wa} target="_blank" rel="noopener noreferrer" className="link text-sm">Discuss on WhatsApp</a>}
            </div>
          </div>
        </div>
      </section>

      {/* Curated */}
      {curated && (
        <section className="wrap pt-24" aria-labelledby="curated-title">
          <h2 id="curated-title" className="mb-10 font-display text-title">{curated.title}</h2>
          <ProductGrid products={curated.items} ctx={ctx} />
        </section>
      )}

      {/* Occasions */}
      {h.occasions?.length > 0 && (
        <section className="wrap pt-24" aria-labelledby="occasions-title">
          <h2 id="occasions-title" className="mb-10 max-w-xl font-display text-title">Dressed for the occasion</h2>
          <ul className="grid gap-10 md:grid-cols-3">
            {h.occasions.map((o) => (
              <li key={o.title} className="border-t border-gold pt-6">
                <Link href={o.href || '/shop'} className="group block">
                  <h3 className="font-display text-2xl group-hover:text-wine">{o.title}</h3>
                  <p className="mt-2 text-muted">{o.text}</p>
                </Link>
              </li>
            ))}
          </ul>
        </section>
      )}

      {/* Apparel & corporate */}
      <section className="mt-28 bg-charcoal text-ivory" aria-labelledby="apparel-title">
        <div className="wrap grid gap-12 py-20 md:grid-cols-12 md:items-center">
          <div className="md:col-span-6">
            <h2 id="apparel-title" className="font-display text-title">{h.apparel.heading}</h2>
            <p className="mt-5 max-w-lg text-ivory/75">{h.apparel.text}</p>
            <div className="mt-10 flex flex-wrap items-center gap-6">
              <Link href="/bulk-orders" className="btn btn-light">Request a bulk quotation</Link>
              <Link href="/collections/branded-polos" className="border-b border-gold pb-1 text-sm hover:text-gold">Branded polos</Link>
              <Link href="/collections/branded-t-shirts" className="border-b border-gold pb-1 text-sm hover:text-gold">Branded T-shirts</Link>
            </div>
          </div>
          <div className="relative aspect-[16/11] md:col-span-5 md:col-start-8">
            <Photo src={h.apparel.image_url} alt={h.apparel.image_alt} sizes="(min-width: 768px) 40vw, 90vw" dark placeholderLabel="Branded apparel photograph coming soon" />
          </div>
        </div>
      </section>

      {/* Story */}
      <section className="wrap grid gap-12 pt-28 md:grid-cols-12" aria-labelledby="story-title">
        <div className="md:col-span-4">
          <div className="arch relative aspect-[3/4] w-full max-w-xs">
            <Photo src={h.story.image_url} alt={h.story.image_alt} sizes="(min-width: 768px) 28vw, 80vw" placeholderLabel="Studio photograph coming soon" />
          </div>
        </div>
        <div className="md:col-span-7 md:col-start-6">
          <h2 id="story-title" className="font-display text-title">{h.story.heading}</h2>
          <div className="mt-6 max-w-[34rem] space-y-5 font-display text-xl leading-relaxed">
            {h.story.body.split(/\n{2,}/).map((para, i) => <p key={i}>{para}</p>)}
          </div>
          <Link href="/about" className="link mt-8 inline-block text-sm">About JJ BLINKS</Link>
        </div>
      </section>
    </>
  );
}

/** Split "A Crown of Culture. A Statement of Style." into its sentences for the two-line set. */
function splitHeadline(text) {
  const parts = String(text || '').match(/[^.!?]+[.!?]?/g)?.map((s) => s.trim()).filter(Boolean) || [];
  return parts.length ? parts : [text];
}
